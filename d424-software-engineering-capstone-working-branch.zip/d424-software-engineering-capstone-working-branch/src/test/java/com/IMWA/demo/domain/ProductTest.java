package com.IMWA.demo.domain;

import com.IMWA.demo.DemoApplication;
import com.IMWA.demo.domain.InhousePart;
import com.IMWA.demo.domain.OutsourcedPart;
import com.IMWA.demo.domain.Part;
import com.IMWA.demo.domain.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;



@SpringBootTest(classes = DemoApplication.class)
class ProductTest {
    Product product;
    @BeforeEach
    public void setUp(){
        product=new Product();
    }
    @Test
    void getId() {
        Long idValue=4L;
        product.setId(idValue);
        assertEquals(product.getId(), idValue);
    }

    @Test
    void setId() {
        Long idValue=4L;
        product.setId(idValue);
        assertEquals(product.getId(), idValue);
    }

    @Test
    void getName() {
        String name="test product";
        product.setName(name);
        assertEquals(name,product.getName());
    }

    @Test
    void setName() {
        String name="test product";
        product.setName(name);
        assertEquals(name,product.getName());
    }

    @Test
    void getPrice() {
        double price=1.0;
        product.setPrice(price);
        assertEquals(price,product.getPrice());
    }

    @Test
    void setPrice() {
        double price=1.0;
        product.setPrice(price);
        assertEquals(price,product.getPrice());
    }

    @Test
    void getInv() {
        int inv=5;
        product.setInv(inv);
        assertEquals(inv,product.getInv());
    }

    @Test
    void setInv() {
        int inv=5;
        product.setInv(inv);
        assertEquals(inv,product.getInv());
    }

    @Test
    void getParts() {
        Part part1 = new OutsourcedPart();
        Part part2 = new InhousePart();
        Set<Part> myParts= new HashSet<>();
        myParts.add(part1);
        myParts.add(part2);
        product.setParts(myParts);
        assertEquals(myParts,product.getParts());
    }

    @Test
    void setParts() {
        Part part1 = new OutsourcedPart();
        Part part2 = new InhousePart();
        Set<Part> myParts= new HashSet<>();
        myParts.add(part1);
        myParts.add(part2);
        product.setParts(myParts);
        assertEquals(myParts,product.getParts());
    }

    @Test
    void testToString() {
        String name="test product";
        product.setName(name);
        assertEquals(name,product.toString());
    }

    @Test
    void testEquals() {
        product.setId(1l);
        Product newProduct= new Product();
        newProduct.setId(1l);
        assertEquals(product,newProduct);
    }

    @Test
    void testHashCode() {
        product.setId(1l);
        Product newProduct= new Product();
        newProduct.setId(1l);
        assertEquals(product.hashCode(),newProduct.hashCode());
    }
}