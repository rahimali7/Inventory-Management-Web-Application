package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.Part;
import com.IMWA.demo.repositories.PartRepository;
import com.lowagie.text.Element;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;
import com.lowagie.text.Document;

@Controller
public class PartPdfController {

    @Autowired
    private PartRepository partRepository;
    public static String dollarSign = "$";
    private final LocalDate myDate = LocalDate.now();

    @GetMapping("/parts/pdf")
    public ResponseEntity<InputStreamResource> generatePdf() {
        List<Part> parts = (List<Part>) partRepository.findAll();

        // Create a PDF document using OpenPDF
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try (Document document = new Document()) {
            PdfWriter.getInstance(document, outputStream);
            document.open();

            // Add title and table content
            //document.add(new Paragraph("Products Report"));
            Paragraph title = new Paragraph("Parts Report");
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Add a Date stamp
            Paragraph date = new Paragraph("Date: " + String.valueOf(myDate));
            date.setAlignment(Element.ALIGN_CENTER);
            document.add(date);

            // Add space (empty paragraph)
            document.add(new Paragraph("\n"));
            PdfPTable table = new PdfPTable(6);
            table.addCell("ID");
            table.addCell("Name");
            table.addCell("Price");
            table.addCell("Inv");
            table.addCell("Min Inv");
            table.addCell("Max Inv");
            for (Part part : parts) {
                table.addCell(String.valueOf(part.getId()));
                table.addCell(part.getName());
                table.addCell(dollarSign + String.valueOf(part.getPrice()));
                table.addCell(String.valueOf(part.getInv()));
                table.addCell(String.valueOf(part.getMinInv()));
                table.addCell(String.valueOf(part.getMaxInv()));
            }
            document.add(table);

            document.close();
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        }

        // Return the PDF as a downloadable file
        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=parts_report.pdf");
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(inputStream));
    }

}
