package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.InhousePart;
import com.IMWA.demo.domain.Part;
import com.IMWA.demo.service.InhousePartService;
import com.IMWA.demo.service.InhousePartServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 *
 *
 *
 */
@Controller
public class AddInhousePartController{
    @Autowired
    private ApplicationContext context;

    Part part;

    @GetMapping("/showFormAddInPart")
    public String showFormAddInhousePart(Model theModel){
        InhousePart inhousepart=new InhousePart();
        theModel.addAttribute("inhousepart",inhousepart);
        return "InhousePartForm";
    }

    @PostMapping("/showFormAddInPart")
    public String submitForm(@Valid @ModelAttribute("inhousepart") InhousePart part, BindingResult theBindingResult, Model theModel){
        theModel.addAttribute("inhousepart",part);
        if (part.getInv() < part.getMinInv()) {
            theBindingResult.rejectValue("inv", "error.inv", "Inventory is less than the min inventory");
            return "InhousePartForm";
        }
        else if (part.getInv() > part.getMaxInv()){
            theBindingResult.rejectValue("inv", "error.inv", "Inventory is greater than the max inventory");
            return "InhousePartForm";
        }
        else if(theBindingResult.hasErrors() || (!part.correctInventory())) {
            theBindingResult.rejectValue("inv", "error.inv","Inventory must between min Inventory and max inventory!");
            return "InhousePartForm";
        }
        else{
        InhousePartService repo=context.getBean(InhousePartServiceImpl.class);
        InhousePart ip=repo.findById((int)part.getId());
        if(ip!=null)part.setProducts(ip.getProducts());
        repo.save(part);

        return "confirmationaddpart";
        }
    }

}
