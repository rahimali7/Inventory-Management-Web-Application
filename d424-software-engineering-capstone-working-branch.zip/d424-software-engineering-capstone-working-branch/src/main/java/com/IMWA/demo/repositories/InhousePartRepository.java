package com.IMWA.demo.repositories;


import com.IMWA.demo.domain.InhousePart;
import org.springframework.data.repository.CrudRepository;

/**
 *
 *
 *
 *
 */
public interface InhousePartRepository extends CrudRepository<InhousePart,Long> {
}
