package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.Product;
import com.IMWA.demo.service.ProductService;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ProductsController {

    private final ProductService productService;

    private List<Product> theProducts;



    public ProductsController(ProductService productService){
        this.productService=productService;
    }


    @GetMapping("/products")
    public String listProducts(Model theModel, @Param("productkeyword") String productkeyword){
        //    theModel.addAttribute("products",productService.findAll());
        List<Product> productList=productService.listAll(productkeyword);
        theModel.addAttribute("page", "products");
        theModel.addAttribute("products", productList);
        theModel.addAttribute("productkeyword", productkeyword);
        return "products";
    }
}
