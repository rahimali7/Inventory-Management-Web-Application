package com.IMWA.demo.repositories;


import com.IMWA.demo.domain.OutsourcedPart;
import org.springframework.data.repository.CrudRepository;

/**
 *
 *
 *
 *
 */
public interface OutsourcedPartRepository extends CrudRepository<OutsourcedPart,Long> {
}
