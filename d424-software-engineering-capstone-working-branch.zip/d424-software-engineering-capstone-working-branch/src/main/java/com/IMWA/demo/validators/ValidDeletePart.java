package com.IMWA.demo.validators;


import jakarta.validation.Payload;

/**
 *
 *
 *
 *
 */
public @interface ValidDeletePart {
    String message() default "Part cannot be deleted if used in a product.";
    Class<?> [] groups() default {};
    Class<? extends Payload> [] payload() default {};
}

