package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.Part;
import com.IMWA.demo.service.PartService;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class PartsController {

    private final PartService partService;

    private List<Part> theParts;



    public PartsController(PartService partService){
        this.partService=partService;
    }


    @GetMapping("/parts")
    public String listParts(Model theModel, @Param("partkeyword") String partkeyword){
        //    theModel.addAttribute("products",productService.findAll());
        List<Part> partList=partService.listAll(partkeyword);
        theModel.addAttribute("page", "parts");
        theModel.addAttribute("parts", partList);
        theModel.addAttribute("partkeyword", partkeyword);
        return "parts";
    }
}
