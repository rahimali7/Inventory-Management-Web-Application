package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.Product;
import com.IMWA.demo.repositories.ProductRepository;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;

@Controller
public class ProductPdfController {
    @Autowired
    private ProductRepository productRepository;
    public static String dollarSign = "$";
    private final LocalDate myDate = LocalDate.now();

    @GetMapping("/products/pdf")
    public ResponseEntity<InputStreamResource> generatePdf() {
        List<Product> products = (List<Product>) productRepository.findAll();

        // Create a PDF document using OpenPDF
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try (Document document = new Document()) {
            PdfWriter.getInstance(document, outputStream);
            document.open();

            // Add title and table content
            //document.add(new Paragraph("Products Report"));
            Paragraph title = new Paragraph("Products Report");
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Paragraph date = new Paragraph("Date: " + String.valueOf(myDate));
            date.setAlignment(Element.ALIGN_CENTER);
            document.add(date);
            // Add space (empty paragraph)
            document.add(new Paragraph("\n"));
            PdfPTable table = new PdfPTable(4);
            table.addCell("ID");
            table.addCell("Name");
            table.addCell("Price");
            table.addCell("Inv");
            for (Product product : products) {
                table.addCell(String.valueOf(product.getId()));
                table.addCell(product.getName());
                table.addCell(dollarSign + String.valueOf(product.getPrice()));
                table.addCell(String.valueOf(product.getInv()));
            }
            document.add(table);

            document.close();
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        }

        // Return the PDF as a downloadable file
        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=products_report.pdf");
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(inputStream));
    }
}
