package com.IMWA.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 *
 *
 *
 */

@Controller
public class FAQController {



    public FAQController(){
    }
    @GetMapping("/faq")
    public String getAboutUs(Model theModel){
        theModel.addAttribute("page", "faq");
        return "faq";
    }
}
