package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.OutsourcedPart;
import com.IMWA.demo.domain.Part;
import com.IMWA.demo.service.OutsourcedPartService;
import com.IMWA.demo.service.OutsourcedPartServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 *
 *
 *
 */
@Controller
public class AddOutsourcedPartController {
    @Autowired
    private ApplicationContext context;
    Part part;

    @GetMapping("/showFormAddOutPart")
    public String showFormAddOutsourcedPart(Model theModel){
        Part part=new OutsourcedPart();
        theModel.addAttribute("outsourcedpart",part);
        return "OutsourcedPartForm";
    }

    @PostMapping("/showFormAddOutPart")
    public String submitForm(@Valid @ModelAttribute("outsourcedpart") OutsourcedPart part, BindingResult bindingResult, Model theModel){
        theModel.addAttribute("outsourcedpart",part);
        if (part.getInv() < part.getMinInv()) {
            bindingResult.rejectValue("inv", "error.inv", "Inventory is less than the min inventory");
            return "OutsourcedPartForm";
        }
        else if (part.getInv() > part.getMaxInv()){
            bindingResult.rejectValue("inv", "error.inv", "Inventory is greater than the max inventory");
            return "OutsourcedPartForm";
        }
        if((bindingResult.hasErrors() || (!part.correctInventory()))) {
            bindingResult.rejectValue("inv", "error.inv","Inventory must between min Inventory and max inventory!");
            return "OutsourcedPartForm";
        }
        else{
        OutsourcedPartService repo=context.getBean(OutsourcedPartServiceImpl.class);
        OutsourcedPart op=repo.findById((int)part.getId());
        if(op!=null)part.setProducts(op.getProducts());
            repo.save(part);
        return "confirmationaddpart";}
    }



}
