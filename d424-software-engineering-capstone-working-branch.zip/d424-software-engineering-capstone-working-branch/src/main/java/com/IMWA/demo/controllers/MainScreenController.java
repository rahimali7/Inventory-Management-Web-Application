package com.IMWA.demo.controllers;


import com.IMWA.demo.domain.Part;
import com.IMWA.demo.domain.Product;
import com.IMWA.demo.service.PartService;
import com.IMWA.demo.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 *
 *
 *
 *
 */

@Controller
public class MainScreenController {
   // private final PartRepository partRepository;
   // private final ProductRepository productRepository;'

    private PartService partService;
    private ProductService productService;

    private List<Part> theParts;
    private List<Product> theProducts;

 /*   public MainScreenControllerr(PartRepository partRepository, ProductRepository productRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
    }*/

    public MainScreenController(PartService partService, ProductService productService){
        this.partService=partService;
        this.productService=productService;
    }


    @GetMapping("/mainscreen")
    public String mainScreen(Model model){
        model.addAttribute("page", "mainscreen");
        return "mainscreen";
    }
}
